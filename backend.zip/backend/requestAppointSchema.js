
const mongoose=require('mongoose')

const schema=new mongoose.Schema({
    doctorname:{
        type:mongoose.Types.ObjectId,
        ref:"doctor"
    },
    hospital:String,
    patient:{
        type:mongoose.Types.ObjectId,
        ref:"patient"
    },
    
},{timestamps:true})

const RequestAppointment=new mongoose.model("appointment_request",schema);
module.exports= RequestAppointment

