const mongoose=require('mongoose')

const schema=new mongoose.Schema({
    patient:{
        type:mongoose.Types.ObjectId,
        ref:"patient"
    },
    link:String
},{timestamps:true})

const Staff=new mongoose.model("labreport",schema);
module.exports= Staff

