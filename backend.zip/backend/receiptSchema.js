
const mongoose=require('mongoose')

const schema=new mongoose.Schema({
    patientId:{
        type:mongoose.Types.ObjectId,
        ref:"patient"
    },
    pharmacy:{
        type:mongoose.Types.ObjectId,
        ref:"pharmacy"
    },
    medicine:{
        type:mongoose.Types.ObjectId,
        ref:"medicine"
    },
    
},{timestamps:true})

const Receipt=new mongoose.model("receipt",schema);
module.exports= Receipt