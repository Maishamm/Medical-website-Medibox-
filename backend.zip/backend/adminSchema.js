const mongoose=require('mongoose')

const schema=new mongoose.Schema({
    email:{
        type:String,
        unique:true
    },
    password: {
        type:String,
        required:true
    },
    role:{
        type:String,
        default:'admin'
    },

},{timestamps:true})

const admin=new mongoose.model("admin",schema);
module.exports= admin
