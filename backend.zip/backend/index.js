const express=require('express')
const app=express();
const PORT=5000
const mongodb='mongodb+srv://medibox:medibox@cluster0.kvkov.mongodb.net/myFirstDatabase?retryWrites=true&w=majority'
const Patient=require('./patientSchema');
// const Staff=require('./staffSchema')
const Hospital=require('./hospitalSchema')
const mongoose=require('mongoose')
const bcrypt=require('bcrypt')
const PatientHandler=require('./Patient/PatientRequest')
const HospitalHandler=require('./Hospital/HospitalRequest')
const PharmacyHandler=require('./Pharmacy/PharmacyRequests')
const LaboratoryHandler=require('./Laboratory/LaboratoryRequest')
const AdminHandler=require('./Admin/AdminRequest')
app.use(express.json());
app.use('/admin',AdminHandler)
app.use('/patient',PatientHandler)
app.use('/hospital',HospitalHandler)
app.use('/pharmacy',PharmacyHandler)
app.use('/laboratory',LaboratoryHandler)
mongoose.connect(mongodb)
.then(()=>{
    console.log("Database connected")
})

app.get("/",(req,res)=>{
    res.send("Hello")
})

app.post('/signin',async(req,res)=>{
    const user=await Patient.findOne({email:req.body.email})
    
    if(user){
        const matchResult=await bcrypt.compare(req.body.password,user.password)
        if(matchResult){
            res.status(200).json(user)
        }
        else{
            res.status(404).json("Not found")
        }
    }
    else{
        res.status(404).json("Not found")
    }
    
})

app.post('/signup',async(req,res)=>{

    const hashedPassword=await bcrypt.hash(req.body.password,10);
    req.body.password=hashedPassword;
    const obj= new Patient({
        first_name:req.body.first_name,
        last_name:req.body.last_name,
        phone_number:req.body.phone_number,
        email:req.body.email,
        password:req.body.password
    })
    await obj.save();
    res.status(200).json("Successful");
})

app.listen(PORT,()=>{
    console.log("Server is running at port "+PORT)
})