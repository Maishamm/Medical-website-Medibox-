
const mongoose=require('mongoose')

const schema=new mongoose.Schema({
    name: String,
    email:{
        type:String,
        unique:true
    },
    password: {
        type:String,
        required:true
    },
    role:{
        type:String,
        default:'laboratory'
    },

},{timestamps:true})

const laboratory=new mongoose.model("laboratory",schema);
module.exports= laboratory
