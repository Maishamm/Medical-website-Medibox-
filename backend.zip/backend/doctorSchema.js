const { type } = require('express/lib/response');
const mongoose=require('mongoose')

const doctorSchema=new mongoose.Schema({
    first_name:String,
    last_name:String,
    contact:String,
    degree:String,
    specialist:String    ,
    role:{
        type:String,
        default:'doctor'
    },
    hospital:{
        type:mongoose.Types.ObjectId,
        ref:"hospital"
    },
},{timestamps:true})

const Doctor=new mongoose.model("doctor",doctorSchema);
module.exports= Doctor

