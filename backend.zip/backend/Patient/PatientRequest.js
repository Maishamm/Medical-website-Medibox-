const router=require('express').Router();
const Patient=require('../patientSchema')
const Order=require('../orderShcema')
const Appointment=require('../appointmentSchema')
const Medicine=require('../medicineSchema')
const LabReport=require("../labreportSchema")
const RequestAppointment=require('../requestAppointSchema')

router.post("/updatePatient",async(req,res)=>{
    obj={
        first_name:req.body.first_name,
        last_name:req.body.last_name,
        email:req.body.email,
        blood_group:req.body.blood_group,
        age:req.body.age,
        gender:req.body.gender, 
    }
    const update=await Patient.findByIdAndUpdate(req.body._id,{$set:obj},{new:true})
    
    res.status(200).json(update)
})

router.get('/getPatient/:id',async(req,res)=>{
    const patient=await Patient.findOne({_id:req.params.id});
    res.status(200).json(patient)
})

router.get('/getPatients',async(req,res)=>{
    const patient=await Patient.find({});
    res.status(200).json(patient)
})


router.get('/getappointments/:id',async(req,res)=>{
    const appointment=await Appointment.find({patient:req.params.id}).populate("doctorname");
    res.status(200).json(appointment)
})
router.post('/addhealthIssue',async(req,res)=>{
    let problem=await Patient.updateOne({"_id":req.body.patientId},{
        $push:{healthIssue:req.body.problem}
    });
    const user=await Patient.findOne({_id:req.body.patientId})
    res.status(200).json(user)
})

router.post('/addprescribe',async(req,res)=>{
    let problem=await Patient.updateOne({"_id":req.body.patientId},{
        $push:{previouslyPrescribe:req.body.prescribe}
    });
    const user=await Patient.findOne({_id:req.body.patientId})
    res.status(200).json(user)
})

router.post('/deleteProblem',async(req,res)=>{
    
    const update=await Patient.findOneAndUpdate(
        { _id: req.body.patientId },
        { $pull: { healthIssue: { $in: [ req.body.problem ] }} },
        { new: true }
      )
      res.status(200).json(update)
})

router.post('/deletePrescribe',async(req,res)=>{
    
    const update=await Patient.findOneAndUpdate(
        { _id: req.body.patientId },
        { $pull: { previouslyPrescribe: { $in: [ req.body.problem ] }} },
        { new: true }
      )
      res.status(200).json(update)
})


router.post('/addmedicine',(req,res)=>{
    const obj={
        user:req.body.userid,
        medicine:req.body.medicineid,
        quantity:req.body.quantity
    }

})

router.post('/addtocart',(req,res)=>{
    req.body['status']=0

    const obj=new Order(req.body)
    obj.save()

    res.status(200).json("success")

})

router.get('/getCarts/:id',async(req,res)=>{
    
    const carts=await Order.find({user:req.params.id,status:0}).populate('medicine')
    res.status(200).json(carts)
})
router.get('/deletecart/:id',async(req,res)=>{
    const obj=await Order.findByIdAndRemove(req.params.id)
    res.status(200).json("success")
})

router.get('/placeorder/:id',async(req,res)=>{
    const carts=await Order.find({user:req.params.id,status:0}).populate('medicine')
    for(let i=0; i<carts.length; i++){
        
        await Order.updateOne({_id:carts[i]._id}, { status: 1 });
        await Medicine.updateOne({_id:carts[i].medicine._id},{quantity:carts[i].medicine.quantity-carts[i].quantity})
    }

    res.status(200).json("Success")

})

router.get("/deleteappointment/:id",async(req,res)=>{
    const obj=await Appointment.findByIdAndRemove(req.params.id);
    res.status(200).json("msg")
})


router.get('/getreport/:id',async(req,res)=>{
    const reports=await LabReport.find({patient:req.params.id})
    res.status(200).json(reports)
})

router.post("/requestappointment",async(req,res)=>{
    const obj=new RequestAppointment(req.body)
    obj.save()

res.status(200).json("msg")
})

router.get("/getappointmentrequests/:hospitalid",async(req,res)=>{
    const requests=await RequestAppointment.find({hospital:req.params.hospitalid}).populate("patient doctorname")
    res.status(200).json(requests)
})

router.get("/deleteappointmentrequest/:id",async(req,res)=>{
    const obj=await RequestAppointment.findByIdAndRemove(req.params.id)
    res.status(200).json("sds")
})

router.get('/deletelabreport/:id',async(req,res)=>{
    const obj=await LabReport.findByIdAndRemove(req.params.id);
    res.status(200).json("msg")
})

module.exports=router