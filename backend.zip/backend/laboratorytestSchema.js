
const mongoose=require('mongoose')

const schema=new mongoose.Schema({
    name: String,
    price:String

},{timestamps:true})

const laboratorytest=new mongoose.model("laboratorytest",schema);
module.exports= laboratorytest
