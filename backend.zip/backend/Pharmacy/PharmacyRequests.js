const router=require('express').Router();
const Pharmacy=require('../pharmacySchema')
const bcrypt=require('bcrypt')
const Medicine=require('../medicineSchema');
const { json } = require('express/lib/response');

router.post('/addpharmacy',async(req,res)=>{
    console.log(req.body)
    req.body.password=await bcrypt.hash(req.body.password,10)
    const saveData=new Pharmacy(req.body)
    await saveData.save()
    res.status(200).json({'msg':"Success"})
})


router.post('/addmedicine',async(req,res)=>{
    const obj=new Medicine(req.body);
    await obj.save();
    res.status(200).json("success")
})

router.get('/getmedicines',async(req,res)=>{
    const medicine=await Medicine.find({});
    res.status(200).json(medicine)
})

router.post('/editmedicine',async(req,res)=>{
    try {
        const update=await Medicine.findByIdAndUpdate(req.body._id, { $set:  req.body })
        res.status(200).json("success")
    } catch (error) {
        
    }
    
})

router.post('/deletemedicine',async(req,res)=>{
    try {
        const abc=await Medicine.findByIdAndRemove(req.body.id)
        res.status(200).json("success")
    } catch (error) {
        
    }
    
})

router.post('/login',async(req,res)=>{
    
    PharmacyData=await Pharmacy.findOne({email:req.body.email})
    try {
        if(PharmacyData){
            matchPass=await bcrypt.compare(req.body.password,PharmacyData.password)
            if(matchPass){
                res.status(200).json(PharmacyData)
            }
            else{
                res.status(500).json({"msg":"painai"})
            }
        }
        else{
            res.status(500).json({"msg":"painai"})
        }
    } catch (error) {
        
    }
    
})

module.exports=router