
const mongoose=require('mongoose')

const schema=new mongoose.Schema({
    first_name:String,
    last_name:String,
    phone_number:String,
    blood_group:String,
    role:{
        type:String,
        default:'patient'
    },
    age:Number,
    gender:String,
    email:{
        type:String,
        unique:true
    },
    password:String,
    healthIssue:[
        String
    ],
    previouslyPrescribe:[String],
    suggestedMedicine:[String]
},{timestamps:true})

const User=new mongoose.model("patient",schema);
module.exports= User

