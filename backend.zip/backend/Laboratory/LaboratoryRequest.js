const router=require('express').Router();
const Laboratory=require('../laboratorySchema')
const bcrypt=require('bcrypt')
const LabTest=require('../laboratorytestSchema')
const LabReport=require('../labreportSchema')

router.post('/addlaboratory',async(req,res)=>{
    console.log(req.body)
    req.body.password=await bcrypt.hash(req.body.password,10)
    const saveData=new Laboratory(req.body)
    await saveData.save()
    res.status(200).json({'msg':"Success"})
})

router.post('/login',async(req,res)=>{
    
    LaboratoryData=await Laboratory.findOne({email:req.body.email})
    
    try {
        if(LaboratoryData){
            matchPass=await bcrypt.compare(req.body.password,LaboratoryData.password)
            if(matchPass){
                
                res.status(200).json(LaboratoryData)
            }
            else{
                
                res.status(500).json({"msg":"painai"})
            }
        }
        else{
            res.status(500).json({"msg":"painai"})
        }
    } catch (error) {
        
    }
    
})

router.post('/addtest',async(req,res)=>{
    const saveData=new LabTest(req.body)
    await saveData.save()
    res.status(200).json({'msg':"Success"})
})

router.get("/gettests",async(req,res)=>{
    const tests=await LabTest.find({})
    res.status(200).json(tests)
})

router.post('/updatetest',async(req,res)=>{
    
    const obj=await LabTest.findByIdAndUpdate(req.body._id,req.body)
    res.status(200).json("success")
})


router.get('/deletetest/:id',async(req,res)=>{
    const del=await LabTest.findByIdAndRemove(req.params.id)
    res.status(200).json("Success")
})

router.post('/sendreport',async(req,res)=>{
    const obj=new LabReport(req.body)
    obj.save()
    res.status(200).json("Success")
})
module.exports=router