const { type } = require('express/lib/response');
const mongoose=require('mongoose')

const donarSchema=new mongoose.Schema({
    name:String,
    phone:String,
    blood:String,
},{timestamps:true})

const Donar=new mongoose.model("donar",donarSchema);
module.exports= Donar

