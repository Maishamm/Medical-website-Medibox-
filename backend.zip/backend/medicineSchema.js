
const mongoose=require('mongoose')

const schema=new mongoose.Schema({
    name:String,
    price:Number,
    quantity:Number,
    pharmacy:{
        type:mongoose.Types.ObjectId,
        ref:"pharmacy"
    },
    
},{timestamps:true})

const Medicine=new mongoose.model("medicine",schema);
module.exports= Medicine

