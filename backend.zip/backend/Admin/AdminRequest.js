const router=require('express').Router();
const Admin=require('../adminSchema')
const Donar=require('../donarSchema')



router.post('/login',async(req,res)=>{
    
    const admin=await Admin.findOne({email:req.body.email})
    
    try {
        if(admin){
            
            if(req.body.password==admin.password){
                
                res.status(200).json(admin)
            }
            else{
                
                res.status(500).json({"msg":"painai"})
            }
        }
        else{
            res.status(500).json({"msg":"painai"})
        }
    } catch (error) {
        
    }
    
})

router.post('/adddonar',async(req,res)=>{
    const obj=new Donar(req.body)
    obj.save()
    res.status(200).json("Success")
})

router.post('/updatedonar',async(req,res)=>{
    const obj=await Donar.findByIdAndUpdate(req.body._id,req.body)
    res.status(200).json("success")
})

router.get('/getdonars',async(req,res)=>{
    const donars=await Donar.find({})
    res.status(200).json(donars)
})

router.get('/deletedonar/:id',async(req,res)=>{
    const del=await Donar.findByIdAndRemove(req.params.id)
    res.status(200).json("Success")
})
module.exports=router