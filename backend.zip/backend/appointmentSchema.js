
const mongoose=require('mongoose')

const schema=new mongoose.Schema({
    doctorname:{
        type:mongoose.Types.ObjectId,
        ref:"doctor"
    },
    hospitalname:String,
    date:String,
    time:String,
    patient:{
        type:mongoose.Types.ObjectId,
        ref:"patient"
    },
    
},{timestamps:true})

const Appointmnet=new mongoose.model("appointment",schema);
module.exports= Appointmnet

