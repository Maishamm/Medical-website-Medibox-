const mongoose=require('mongoose')

const schema=new mongoose.Schema({
    user:{
        type:mongoose.Types.ObjectId,
        ref:"patient"
    },
    medicine:{
        type:mongoose.Types.ObjectId,
        ref:"medicine"
    },
    quantity:Number,
    status:0

    
},{timestamps:true})

const Order=new mongoose.model("order",schema);
module.exports= Order

