const mongoose=require('mongoose')

const schema=new mongoose.Schema({
    title:String,
    district:String,
    area:String,
    email:{
        type:String,
        unique:true
    },
    password:{
        type:String,
        required:true
    },
    phone:{
        type:String
    },
    role:{
        type:String,
        default:'hospital'
    }
},{timestamps:true})

const Hospital=new mongoose.model("hospital",schema);
module.exports= Hospital

