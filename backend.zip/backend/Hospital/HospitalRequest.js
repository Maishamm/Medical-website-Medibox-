const router=require('express').Router();
const Hospital=require('../hospitalSchema')
const Appointment=require('../appointmentSchema')
const bcrypt=require('bcrypt');
const Doctor = require('../doctorSchema');



router.post('/addhospital',async(req,res)=>{
    req.body.password=await bcrypt.hash(req.body.password,10)
    const saveData=new Hospital(req.body)
    await saveData.save()
    res.status(200).json({'msg':"Success"})
})

router.post('/makeappointment',async(req,res)=>{
    
    const obj=new Appointment(req.body)
    obj.save()
    res.status(200).json({'msg':"Success"})
})

router.post('/login',async(req,res)=>{
    
    HospitalData=await Hospital.findOne({email:req.body.email})
    
    try {
        if(HospitalData){
            matchPass=await bcrypt.compare(req.body.password,HospitalData.password)
            if(matchPass){
                
                res.status(200).json(HospitalData)
            }
            else{
                
                res.status(500).json({"msg":"painai"})
            }
        }
        else{
            res.status(500).json({"msg":"painai"})
        }
    } catch (error) {
        
    }
    
})

router.post("/update",async(req,res)=>{
    const obj=await Doctor.findByIdAndUpdate(req.body._id,req.body)
    res.status(200).json("success")
})


router.post("/delete",async(req,res)=>{
    const obj=await Doctor.findByIdAndRemove(req.body._id)
    res.status(200).json("success")
})

router.post("/adddoctor",async(req,res)=>{
    const obj=new Doctor(req.body)
    await obj.save()
    res.status(200).json("Success")
})

router.get("/getdoctors/:id",async(req,res)=>{
    const doctors=await Doctor.find({hospital:req.params.id})
    res.status(200).json(doctors)
})
router.get("/getdoctor",async(req,res)=>{
    const doctors=await Doctor.find().populate('hospital')
    res.status(200).json(doctors)
})

module.exports=router